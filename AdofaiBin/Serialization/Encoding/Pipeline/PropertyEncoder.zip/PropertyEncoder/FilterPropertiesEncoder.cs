﻿#nullable enable
using AdofaiBin.Serialization.DataType;
using AdofaiBin.Serialization.Encoding.IO;

namespace AdofaiBin.Serialization.Encoding.PropertyEncoder;

public class FilterPropertiesEncoder : IPropertyEncoder
{
    /// <inheritdoc />
    public PropertyType Handles { get; } = PropertyType.FilterProperties;

    /// <inheritdoc />
    public void Write(ref WriteCursor cursor, object? value)
    {
        if (value is not FilterProp filterProp)
        {
            filterProp = new FilterProp();
        }

        cursor.WriteByte((byte)filterProp.Type);
        cursor.WriteFloat(filterProp.Number);
        cursor.WriteUtf8String(filterProp.Text);
        cursor.WriteFloat(filterProp.Vec.X);
        cursor.WriteFloat(filterProp.Vec.Y);
    }
}