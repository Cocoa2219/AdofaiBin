﻿#nullable enable
using AdofaiBin.Serialization.DataType;
using AdofaiBin.Serialization.Encoding.IO;

namespace AdofaiBin.Serialization.Encoding.PropertyEncoder;

public class Vector2Encoder : IPropertyEncoder
{
    /// <inheritdoc />
    public PropertyType Handles { get; } = PropertyType.Vector2;

    /// <inheritdoc />
    public void Write(ref WriteCursor cursor, object? value)
    {
        if (value is Vec2 vec)
        {
            cursor.WriteFloat(vec.X);
            cursor.WriteFloat(vec.Y);
        }
        else
        {
            cursor.WriteFloat(0f);
            cursor.WriteFloat(0f);
        }
    }
}