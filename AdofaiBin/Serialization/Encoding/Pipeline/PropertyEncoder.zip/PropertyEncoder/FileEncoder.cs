﻿#nullable enable
using AdofaiBin.Serialization.Encoding.IO;

namespace AdofaiBin.Serialization.Encoding.PropertyEncoder;

public class FileEncoder : IPropertyEncoder
{
    /// <inheritdoc />
    public PropertyType Handles { get; } = PropertyType.File;

    /// <inheritdoc />
    public void Write(ref WriteCursor cursor, object? value)
    {
        // just path as string
        var str = value?.ToString() ?? string.Empty;
        cursor.WriteUtf8String(str);
    }
}