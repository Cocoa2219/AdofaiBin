﻿#nullable enable
using AdofaiBin.Serialization.Encoding.IO;

namespace AdofaiBin.Serialization.Encoding.PropertyEncoder;

public class StringEncoder : IPropertyEncoder
{
    /// <inheritdoc />
    public PropertyType Handles { get; } = PropertyType.String;

    /// <inheritdoc />
    public void Write(ref WriteCursor cursor, object? value)
    {
        var str = value?.ToString() ?? string.Empty;
        cursor.WriteUtf8String(str);
    }
}