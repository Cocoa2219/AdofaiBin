﻿#nullable enable
using AdofaiBin.Serialization.DataType;
using AdofaiBin.Serialization.Encoding.IO;

namespace AdofaiBin.Serialization.Encoding.PropertyEncoder;

public class ColorEncoder : IPropertyEncoder
{
    /// <inheritdoc />
    public PropertyType Handles { get; } = PropertyType.Color;

    /// <inheritdoc />
    public void Write(ref WriteCursor cursor, object? value)
    {
        Color32 color;
        if (value is Color32 c)
        {
            color = c;
        }
        else
        {
            color = new Color32(255, 0, 0, 0);
        }

        cursor.WriteByte(color.A);
        cursor.WriteByte(color.R);
        cursor.WriteByte(color.G);
        cursor.WriteByte(color.B);
    }
}