﻿#nullable enable
using AdofaiBin.Serialization.Encoding.IO;

namespace AdofaiBin.Serialization.Encoding.PropertyEncoder;

public class RatingEncoder : IPropertyEncoder
{
    /// <inheritdoc />
    public PropertyType Handles { get; } = PropertyType.Rating;

    /// <inheritdoc />
    public void Write(ref WriteCursor cursor, object? value)
    {
        var rating = 0;
        if (value is int r)
        {
            rating = r;
        }

        cursor.WriteVarInt(rating);
    }
}