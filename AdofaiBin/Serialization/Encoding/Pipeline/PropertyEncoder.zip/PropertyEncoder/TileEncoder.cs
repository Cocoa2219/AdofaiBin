﻿#nullable enable
using AdofaiBin.Serialization.DataType;
using AdofaiBin.Serialization.Encoding.IO;

namespace AdofaiBin.Serialization.Encoding.PropertyEncoder;

public class TileEncoder : IPropertyEncoder
{
    /// <inheritdoc />
    public PropertyType Handles { get; } = PropertyType.Tile;

    /// <inheritdoc />
    public void Write(ref WriteCursor cursor, object? value)
    {
        if (value is TileRef tileRef)
        {
            cursor.WriteVarInt(tileRef.Index);
            cursor.WriteByte((byte)tileRef.RelativeTo);
        }
        else
        {
            cursor.WriteVarInt(0);
            cursor.WriteByte((byte)TileRelativeTo.ThisTile);
        }
    }
}