﻿#nullable enable
using AdofaiBin.Serialization.DataType;
using AdofaiBin.Serialization.Encoding.IO;

namespace AdofaiBin.Serialization.Encoding.PropertyEncoder;

public class FloatPairEncoder : IPropertyEncoder
{
    /// <inheritdoc />
    public PropertyType Handles { get; } = PropertyType.FloatPair;

    /// <inheritdoc />
    public void Write(ref WriteCursor cursor, object? value)
    {
        var pair = value is FloatPair floatPair ? floatPair : new FloatPair(0f, 0f);
        cursor.WriteFloat(pair.A);
        cursor.WriteFloat(pair.B);
    }
}